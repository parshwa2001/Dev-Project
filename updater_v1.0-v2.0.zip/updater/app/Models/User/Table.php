<?php

namespace App\Models\User;

use Illuminate\Database\Eloquent\Model;

class Table extends Model
{
    public $timestamps = false;
}
