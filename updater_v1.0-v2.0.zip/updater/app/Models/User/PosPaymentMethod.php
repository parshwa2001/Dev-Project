<?php

namespace App\Models\User;

use Illuminate\Database\Eloquent\Model;

class PosPaymentMethod extends Model
{
    //
}
