<?php

namespace App\Models\User;

use Illuminate\Database\Eloquent\Model;

class PostalCode extends Model
{
     protected $guarde =[];
}
